import inquirer from 'inquirer';
import fs from 'fs';
import qr from 'qr-image';

inquirer
.prompt([
    {
        type: "input", // Add 'type' to specify the type of prompt
        message: "What is your URL?", // Use 'message' instead of 'question'
        name: "url"
    },
])
.then((answer)=>{
    const url=answer.url;
    // console.log(answer);
    var qr_img=qr.image(url);
    qr_img.pipe(fs.createWriteStream("qr-image.png"));

})